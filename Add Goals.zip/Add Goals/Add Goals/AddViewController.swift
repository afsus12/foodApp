//
//  AddViewController.swift
//  Add Goals
//
//  Created by user9 on 3/4/2023.
//

import UIKit

class AddViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    

    @IBOutlet weak var tableView: UITableView!
    var goals: [String] = ["g1"]
    
    
    @IBOutlet weak var GoalText: UITextField!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Goals"
        
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        
        tableView.delegate = self
        
        tableView.dataSource = self

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return goals.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = goals[indexPath.row]
        return cell
    }
    

    

    @IBAction func AddGoal(_ sender: Any) {
        if let goal = GoalText.text{
            goals.append(goal)
            tableView.reloadData()
            
        }else {
            print("3abiiiiii ye ham")
        }
    }
    
}
