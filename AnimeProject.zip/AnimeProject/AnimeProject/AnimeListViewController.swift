//
//  AnimeListViewController.swift
//  AnimeProject
//
//  Created by user9 on 10/4/2023.
//

import UIKit

class AnimeListViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!

    var animes: [Anime] = [ Anime(name: "Demon Slayer", releaseDate: "10/12/23", poster: "posterDM"),Anime(name: "Attack on Titan", releaseDate: "10/12/23", poster: "posterAOT"),Anime(name: "HunterxHunter", releaseDate: "10/12/23", poster: "posterHxH")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //register default cell
        let customCell =    UINib(nibName: "TableViewCell", bundle: nil)
        tableView.register(customCell, forCellReuseIdentifier: "cell")
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return animes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
          
        let Anime = animes[indexPath.row]
        cell.nameLabel.text = Anime.name
        cell.dateLabel.text = Anime.releaseDate
        cell.picture.image = UIImage(named: Anime.poster)
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
       
    }


}
//let nib = UINib(nibName: "CustomAnimeCell", bundle: nil)

//title = "Anime List"
