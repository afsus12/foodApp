//
//  anime.swift
//  AnimeProject
//
//  Created by user9 on 13/4/2023.
//

import Foundation
import UIKit

struct Anime
{
    
    var name: String
    var releaseDate: String
    var poster: String
    

        
    }

