//
//  TableViewCell.swift
//  AnimeProject
//
//  Created by user9 on 13/4/2023.
//

import UIKit

class TableViewCell: UITableViewCell {
    @IBOutlet weak  var dateLabel: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var picture: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
