//
//  ListViewController.swift
//  FoodApp
//
//  Created by user9 on 24/4/2023.
//

import UIKit

class ListViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    
    
    
    
    @IBOutlet weak var tableView: UITableView!
    
    var foodList : [Food] = [Food(name: "pizza", city: "napoli", img: "pizza"),Food(name: "beef wellington", city: "england", img: "beef wellington")]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let customCell =    UINib(nibName: "TableViewCell", bundle: nil)
        tableView.register(customCell, forCellReuseIdentifier: "cell")
        tableView.delegate = self
        tableView.dataSource = self
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return foodList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        let food = foodList[indexPath.row]
        cell.foodName.text = food.name
        cell.foodCity.text = food.city
        cell.photo.image = UIImage(named: food.img)
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 220
        
    }
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
                
        let delete = UIContextualAction(style: .destructive, title: "delete"){ _,_,_ in self.foodList.remove(at:indexPath.row)
            //self.tableView.reloadData()
            self.tableView.beginUpdates()
            self.tableView.deleteRows(at: [indexPath], with: .automatic)
            self.tableView.endUpdates()
        }
        
        
        return UISwipeActionsConfiguration(actions:[delete] )
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let alert = UIAlertController(title: "fail", message: "o9aad ghadi ye boujadi", preferredStyle: .alert)
        
        let alertAction = UIAlertAction(title: "ok", style: .default)
        
        alert.addAction(alertAction)
        present(alert, animated: true)
    }
    
    

    
    
}
