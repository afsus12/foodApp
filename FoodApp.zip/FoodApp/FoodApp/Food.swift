//
//  Note.swift
//  Notes
//
//  Created by user9 on 17/4/2023.

import Foundation
import UIKit

struct Food
{
    
    var name: String
    var city: String
    var img: String
        
    }


