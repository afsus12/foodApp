//
//  HomePageViewController.swift
//  Notes
//
//  Created by user9 on 17/4/2023.
//

import UIKit

class HomePageViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {

    

    @IBOutlet weak var titre: UITextField!
    @IBOutlet weak var message: UITextField!
    @IBOutlet weak var tableView: UITableView!
    
    var notes : [Note] = [Note(titreMod: "titre", messageMod: "hkerjfnekrj"),Note(titreMod: "titre2", messageMod: "ghaqssen jaouadi")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        
        let customCell =    UINib(nibName: "TableViewCell", bundle: nil)
        tableView.register(customCell, forCellReuseIdentifier: "cell")
        tableView.delegate = self
        tableView.dataSource = self


     
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
          
        let Note = notes[indexPath.row]
        cell.titre.text = Note.titreMod
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
       
    }
    @IBAction func addNote(_ sender: Any) {
        
       
        if let notTitre = titre.text, let notMsg = message.text{
            let note = Note(titreMod: notTitre, messageMod: notMsg)
            notes.append(note)
            tableView.reloadData()
        }
        else{
            print("nope")
        }
    }
}
