//
//  Note.swift
//  Notes
//
//  Created by user9 on 17/4/2023.

import Foundation
import UIKit

struct Note
{
    
    var titreMod: String
    var messageMod: String
        
    }

